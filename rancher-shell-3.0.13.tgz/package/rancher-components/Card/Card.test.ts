import { mount } from '@vue/test-utils';
import { Card } from './index';

describe('component: Card', () => {
  const title = 'Card title';
  const body = 'Card body';

  it('should have a card title', () => {
    const wrapper = mount(Card, {
      props: { title },
      slots: { title: '<div>Card title</div>' }
    });

    const element = wrapper.find('[data-testid="card-title-slot"]');

    expect(element.exists()).toBe(true);
    expect(element.text()).toBe(title);
  });

  it('should have a card body', () => {
    const wrapper = mount(Card, { slots: { body: '<div>Card body</div>' } });

    const element = wrapper.find('[data-testid="card-body-slot"]');

    expect(element.exists()).toBe(true);
    expect(element.text()).toBe(body);
  });

  it('should display the default card actions', () => {
    const wrapper = mount(Card);
    const element = wrapper.find('[data-testid="card-actions-slot"]');

    expect(element.exists()).toBe(true);
  });

  it('should not have an id on the card title when rendered outside of a modal', () => {
    const wrapper = mount(Card, { slots: { title: '<div>Card title</div>' } });

    expect(wrapper.find('[data-testid="card-title-slot"]').attributes('id')).toBeUndefined();
  });

  it('should mark the card title with data-modal-title for modal labelling', () => {
    const wrapper = mount(Card, { props: { title } });

    expect(wrapper.find('[data-testid="card-title-slot"]').attributes('data-modal-title')).toBeDefined();
  });
});
