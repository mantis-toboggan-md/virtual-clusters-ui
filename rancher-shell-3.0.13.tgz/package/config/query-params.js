// Debugging
export const SPA = 'spa';

// Login/Initial setup
export const LOCAL = 'local';
export const SETUP = 'setup';
export const STEP = 'step';
export const LOGGED_OUT = 'logged-out';
export const IS_SSO = 'is-sso';
export const IS_SLO = 'is-slo';
export const IS_SESSION_IDLE = 'is-session-idle';
export const UPGRADED = 'upgraded';
export const TIMED_OUT = 'timed-out';
export const AUTH_TEST = 'test';
export const BACK_TO = 'back-to';
export const GITHUB_CODE = 'code';
export const GITHUB_NONCE = 'state';
export const GITHUB_SCOPE = 'scope';
export const GITHUB_REDIRECT = 'redirect_uri';

// General
export const _FLAGGED = null; // The value for a key-only flag, like `?desc`
export const _UNFLAG = undefined; // The value to remove a query param

// SortableTable
export const SEARCH_QUERY = 'q';
export const SORT_BY = 'sort';
export const DESCENDING = 'desc';
export const PAGE = 'page';

// ResourceDetail/Yaml
export const MODE = 'mode';
export const _CREATE = 'create';
export const _VIEW = 'view';
export const _EDIT = 'edit';
export const _LIST = 'list';
export const _CLONE = 'clone';
export const _STAGE = 'stage';
export const _IMPORT = 'import';
export const LEGACY = 'legacy';

export const AS = 'as';
export const VIEW = 'view';
export const _DETAIL = 'detail';
export const _CONFIG = 'config';
export const _YAML = 'yaml';
export const _GRAPH = 'graph';
export const FOCUS = 'focus';

export const PREVIEW = 'preview';

export const DIFF = 'diff';
export const _UNIFIED = 'unified';
export const _SPLIT = 'split';

// CruResource
export const SUB_TYPE = 'type';
export const RKE_TYPE = 'rkeType';

// App launch
export const REPO_TYPE = 'repo-type';
export const REPO = 'repo';
export const CHART = 'chart';
export const VERSION = 'version';
export const NAME = 'name';
export const NAMESPACE = 'namespace';
export const DESCRIPTION = 'description';
export const CATEGORY = 'category';
export const TAG = 'tag';
export const STATUS = 'status';
export const DEPRECATED = 'deprecated';
export const HIDDEN = 'hidden';
export const FROM_TOOLS = 'tools';
export const FROM_CLUSTER = 'cluster';
export const NEW_APP_INSTANCE = 'new-instance';
export const HIDE_SIDE_NAV = 'hide-side-nav';

// Cluster provisioning
export const PROVIDER = 'provider';
export const CLOUD_CREDENTIAL = 'cloud';

// NAMESPACE/PROJECT
export const PROJECT_ID = 'projectId';
export const FLAT_VIEW = 'flatView';

/**
 * Used on the secret create/edit page to determine
 * 1. if the user is creating a normal secret, or a project scoped secret
 * 2. where to return the user on cancel/save
 */
export const SECRET_QUERY_PARAMS = {
  NAMESPACED:     'namespaced',
  PROJECT_SCOPED: 'project-scoped'
};
export const SECRET_SCOPE = 'scope';
// RANCHER OIDC CLIENT
export const RANCHER_AS_OIDC_QUERY_PARAMS = ['scope', 'client_id', 'redirect_uri', 'response_type'];

// For REPOSITORIES, to determine which type of repo to create, used on clusterrepo create page
export const TARGET = 'target';
