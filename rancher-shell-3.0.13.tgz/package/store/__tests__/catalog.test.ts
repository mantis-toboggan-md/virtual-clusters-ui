import { CATALOG } from '@shell/config/types';
import { CATALOG as CATALOG_ANNOTATIONS } from '@shell/config/labels-annotations';
import {
  state, getters, actions, mutations, filterAndArrangeCharts, isRancherRepo, compatibleVersionsFor, getPermittedOSs
} from '../catalog';
import { createStore } from 'vuex';

const clusterRepo = { _key: 'testClusterRepo' };
const repoChartName = 'regular-chart';
const repoChart = {
  name:     repoChartName,
  type:     'namespaced',
  version:  1,
  metadata: { name: repoChartName }
};
const deprecatedByFieldChartName = 'deprecated-by-field-chart';
const deprecatedByFieldChart = {
  name:       deprecatedByFieldChartName,
  type:       'namespaced',
  version:    1,
  deprecated: true,
  metadata:   { name: deprecatedByFieldChartName }
};
const deprecatedByAnnotationChartName = 'deprecated-by-annotation-chart';
const deprecatedByAnnotationChart = {
  name:        deprecatedByAnnotationChartName,
  type:        'namespaced',
  version:     1,
  annotations: { [CATALOG_ANNOTATIONS.DEPRECATED]: 'true' },
  metadata:    { name: deprecatedByAnnotationChartName }
};
const repo = {
  metadata:   { name: 'testRepo' },
  _key:       'testRepo',
  links:      { index: 'fetchindex' },
  canLoad:    true,
  followLink: () => ({
    entries: {
      [repoChartName]:                   [repoChart],
      [deprecatedByFieldChartName]:      [deprecatedByFieldChart],
      [deprecatedByAnnotationChartName]: [deprecatedByAnnotationChart]
    }
  })
};

const catalogStoreName = 'catalog';
const clusterStore = 'cluster';

const expectedChartKey = `namespace/${ repo._key }/${ repoChartName }`;
const expectedDeprecatedByFieldChartKey = `namespace/${ repo._key }/${ deprecatedByFieldChartName }`;
const expectedDeprecatedByAnnotationChartKey = `namespace/${ repo._key }/${ deprecatedByAnnotationChartName }`;
const initialVersionInfo = { junk: true };
const initialRawChartName = 'cde';
const initialRawChart = {
  id:       `namespace/${ repo._key }/${ initialRawChartName }`,
  repoKey:  repo._key,
  type:     'namespaced',
  name:     initialRawChartName,
  version:  1,
  metadata: { name: initialRawChartName }
};
const initialRawCharts = { [initialRawChart.id]: initialRawChart };
const initialLoadedInfo = { [repo._key]: true };

describe('catalog', () => {
  describe('load', () => {
    const constructStore = () => {
      const catalogStore = {
        state: state(),
        getters,
        mutations,
        actions,
      };

      return {
        modules: {
          i18n: {
            namespaced: true,
            getters:    { withFallback: (state: any) => () => '' }
          },
          [catalogStoreName]: {
            namespaced: true,
            state:      {
              ...catalogStore.state,
              // Set initial state
              // - repos have been loaded
              // - some charts exist
              // - some chart version info has been fetched
              loaded:       initialLoadedInfo,
              charts:       initialRawCharts,
              versionInfos: initialVersionInfo,
            },
            mutations: catalogStore.mutations,
            actions:   catalogStore.actions,
            getters:   catalogStore.getters
          },
          [clusterStore]: {
            namespaced: true,
            getters:    { schemaFor: (state: any) => (schema: string) => ({}) },
            actions:    {
              findAll: (ctx: any, ...args: any[]) => {
                if (args[0].type === CATALOG.CLUSTER_REPO) {
                  return Promise.resolve([clusterRepo]);
                }
                if (args[0].type === CATALOG.REPO) {
                  return Promise.resolve([repo]);
                }

                return Promise.resolve([]);
              },
            }
          }
        },
        state: {
          $extension:         { getDynamic: () => require(`@shell/models/chart`) },
          [catalogStoreName]: { } as { [key: string]: any},
        },
        getters: {
          currentCluster: () => ({ }),
          currentProduct: () => ({ inStore: clusterStore }),
        },
        mutations: { },
        actions:   { }
      };
    };

    it('no force', async() => {
      const store = createStore(constructStore());

      // Validate initial state of store
      expect(store.getters[`${ catalogStoreName }/rawCharts`]).toStrictEqual(initialRawCharts);
      expect(store.getters[`${ catalogStoreName }/charts`]).toStrictEqual([]);

      // Make the request
      await store.dispatch(`${ catalogStoreName }/load`, {
        force: false,
        reset: false
      });

      // Basics should always be ok
      expect(store.getters[`${ catalogStoreName }/inStore`]).toStrictEqual(clusterStore);
      expect(store.getters[`${ catalogStoreName }/errors`]).toStrictEqual([]);
      expect(store.getters[`${ catalogStoreName }/repos`]).toStrictEqual([clusterRepo, repo]);
      expect(store.state[catalogStoreName].loaded).toStrictEqual(initialLoadedInfo);

      // Store should still be in it's initial state (but charts populated)
      expect(store.getters[`${ catalogStoreName }/rawCharts`]).toStrictEqual(initialRawCharts);
      expect(store.getters[`${ catalogStoreName }/charts`]).toStrictEqual([initialRawChart]);

      // We haven't reset the version info, so it should be unchanged
      expect(store.state[catalogStoreName].versionInfos).toStrictEqual(initialVersionInfo);
    });

    it('force', async() => {
      const store = createStore(constructStore());

      // Validate initial state of store
      let rawCharts = store.getters[`${ catalogStoreName }/rawCharts`];

      expect(store.getters[`${ catalogStoreName }/rawCharts`]).toStrictEqual(initialRawCharts);
      expect(rawCharts[initialRawChart.id]).toBeDefined();
      expect(rawCharts[initialRawChart.id].id).toBe(initialRawChart.id);

      expect(store.getters[`${ catalogStoreName }/charts`]).toStrictEqual([]);

      // Make the request
      await store.dispatch(`${ catalogStoreName }/load`, {
        force: true, // Force such that we should get some values
        reset: false
      });

      rawCharts = store.getters[`${ catalogStoreName }/rawCharts`];
      const charts = store.getters[`${ catalogStoreName }/charts`];

      // Basics should always be ok
      expect(store.getters[`${ catalogStoreName }/inStore`]).toStrictEqual(clusterStore);
      expect(store.getters[`${ catalogStoreName }/errors`]).toStrictEqual([]);
      expect(store.getters[`${ catalogStoreName }/repos`]).toStrictEqual([clusterRepo, repo]);
      expect(store.state[catalogStoreName].loaded).toStrictEqual(initialLoadedInfo);

      // Store should have it's initial chart... and the new one
      expect(rawCharts[initialRawChart.id]).toBeDefined();
      expect(rawCharts[initialRawChart.id].id).toBe(initialRawChart.id);
      expect(rawCharts[expectedChartKey]).toBeDefined();
      expect(rawCharts[expectedChartKey].id).toBe(expectedChartKey);
      expect(rawCharts[expectedChartKey].versions[0].version).toBe(repoChart.version);

      expect(rawCharts[expectedDeprecatedByFieldChartKey]).toBeDefined();
      expect(rawCharts[expectedDeprecatedByFieldChartKey].id).toBe(expectedDeprecatedByFieldChartKey);
      expect(rawCharts[expectedDeprecatedByFieldChartKey].deprecated).toBe(true);

      expect(rawCharts[expectedDeprecatedByAnnotationChartKey]).toBeDefined();
      expect(rawCharts[expectedDeprecatedByAnnotationChartKey].id).toBe(expectedDeprecatedByAnnotationChartKey);
      expect(rawCharts[expectedDeprecatedByAnnotationChartKey].deprecated).toBe(true);

      expect(charts).toHaveLength(4);
      expect(charts.find((c: any) => c.id === initialRawChart.id)).toBeDefined();
      expect(charts.find((c: any) => c.id === expectedChartKey)).toBeDefined();
      expect(charts.find((c: any) => c.id === expectedDeprecatedByFieldChartKey)).toBeDefined();
      expect(charts.find((c: any) => c.id === expectedDeprecatedByAnnotationChartKey)).toBeDefined();

      // Version info should be unchanged
      expect(store.state[catalogStoreName].versionInfos).toStrictEqual(initialVersionInfo);
    });

    it('force + reset', async() => {
      const store = createStore(constructStore());

      // Validate initial state of store
      expect(store.getters[`${ catalogStoreName }/rawCharts`]).toStrictEqual(initialRawCharts);
      expect(store.getters[`${ catalogStoreName }/charts`]).toStrictEqual([]);

      // Make the request
      await store.dispatch(`${ catalogStoreName }/load`, {
        force: true,
        reset: true
      });

      const rawCharts = store.getters[`${ catalogStoreName }/rawCharts`];
      const charts = store.getters[`${ catalogStoreName }/charts`];

      // Basics should always be ok
      expect(store.getters[`${ catalogStoreName }/inStore`]).toStrictEqual(clusterStore);
      expect(store.getters[`${ catalogStoreName }/errors`]).toStrictEqual([]);
      expect(store.getters[`${ catalogStoreName }/repos`]).toStrictEqual([clusterRepo, repo]);
      expect(store.state[catalogStoreName].loaded).toStrictEqual(initialLoadedInfo);

      // Store should NOT have it's initial chart... and should have the new one
      expect(rawCharts[initialRawChart.id]).not.toBeDefined();
      expect(rawCharts[expectedChartKey]).toBeDefined();
      expect(rawCharts[expectedChartKey].id).toBe(expectedChartKey);
      expect(rawCharts[expectedChartKey].versions[0].version).toBe(repoChart.version);

      expect(rawCharts[expectedDeprecatedByFieldChartKey]).toBeDefined();
      expect(rawCharts[expectedDeprecatedByFieldChartKey].id).toBe(expectedDeprecatedByFieldChartKey);
      expect(rawCharts[expectedDeprecatedByFieldChartKey].deprecated).toBe(true);

      expect(rawCharts[expectedDeprecatedByAnnotationChartKey]).toBeDefined();
      expect(rawCharts[expectedDeprecatedByAnnotationChartKey].id).toBe(expectedDeprecatedByAnnotationChartKey);
      expect(rawCharts[expectedDeprecatedByAnnotationChartKey].deprecated).toBe(true);

      expect(charts).toHaveLength(3);
      expect(charts.find((c: any) => c.id === expectedChartKey)).toBeDefined();
      expect(charts.find((c: any) => c.id === expectedDeprecatedByFieldChartKey)).toBeDefined();
      expect(charts.find((c: any) => c.id === expectedDeprecatedByAnnotationChartKey)).toBeDefined();

      // Version info should be changed (it's now empty given reset)
      expect(store.state[catalogStoreName].versionInfos).toStrictEqual({ });
    });

    it('repoKeys provided', async() => {
      const store = createStore(constructStore());

      // Validate initial state of store
      expect(store.getters[`${ catalogStoreName }/rawCharts`]).toStrictEqual(initialRawCharts);
      expect(store.getters[`${ catalogStoreName }/charts`]).toStrictEqual([]);

      // Make the request targeting specific repo (we provide repo._key)
      await store.dispatch(`${ catalogStoreName }/load`, {
        force:    true,
        repoKeys: [repo._key]
      });

      const rawCharts = store.getters[`${ catalogStoreName }/rawCharts`];
      const charts = store.getters[`${ catalogStoreName }/charts`];

      // We expect the old chart belonging to this repo to be wiped out
      // and replaced entirely by the newly fetched chart.
      expect(rawCharts[initialRawChart.id]).not.toBeDefined();
      expect(rawCharts[expectedChartKey]).toBeDefined();
      expect(rawCharts[expectedChartKey].id).toBe(expectedChartKey);
      expect(rawCharts[expectedChartKey].versions[0].version).toBe(repoChart.version);

      expect(rawCharts[expectedDeprecatedByFieldChartKey]).toBeDefined();
      expect(rawCharts[expectedDeprecatedByFieldChartKey].id).toBe(expectedDeprecatedByFieldChartKey);
      expect(rawCharts[expectedDeprecatedByFieldChartKey].deprecated).toBe(true);

      expect(rawCharts[expectedDeprecatedByAnnotationChartKey]).toBeDefined();
      expect(rawCharts[expectedDeprecatedByAnnotationChartKey].id).toBe(expectedDeprecatedByAnnotationChartKey);
      expect(rawCharts[expectedDeprecatedByAnnotationChartKey].deprecated).toBe(true);

      expect(charts).toHaveLength(3);
      expect(charts.find((c: any) => c.id === expectedChartKey)).toBeDefined();
      expect(charts.find((c: any) => c.id === expectedDeprecatedByFieldChartKey)).toBeDefined();
      expect(charts.find((c: any) => c.id === expectedDeprecatedByAnnotationChartKey)).toBeDefined();
    });

    it('repoKeys provided, ignoring unrelated charts and versions', async() => {
      // We will manually inject an unrelated chart to prove it isn't wiped out
      const store = createStore(constructStore());
      const unrelatedChart = {
        id:       `namespace/unrelatedRepo/unrelatedChart`,
        repoKey:  'unrelatedRepo',
        type:     'namespaced',
        name:     'unrelatedChart',
        version:  1,
        metadata: { name: 'unrelatedChart' }
      };

      const targetedVersionKey = `namespace/testRepo/myChart/1.0.0`;
      const unrelatedVersionKey = `namespace/unrelatedRepo/unrelatedChart/1.0.0`;

      store.state[catalogStoreName].charts = {
        ...initialRawCharts,
        [unrelatedChart.id]: unrelatedChart
      };

      store.state[catalogStoreName].versionInfos = {
        [targetedVersionKey]:  { data: 'old-data' },
        [unrelatedVersionKey]: { data: 'keep-me' }
      };

      // Make the request targeting specific repo
      await store.dispatch(`${ catalogStoreName }/load`, {
        force:    true,
        repoKeys: [repo._key]
      });

      const rawCharts = store.getters[`${ catalogStoreName }/rawCharts`];
      const versionInfos = store.state[catalogStoreName].versionInfos;

      // The unrelated chart should NOT be wiped
      expect(rawCharts[unrelatedChart.id]).toBeDefined();
      expect(rawCharts[unrelatedChart.id].repoKey).toBe('unrelatedRepo');

      // The old initialRawChart (with repoKey: repo._key) SHOULD be wiped and replaced
      expect(rawCharts[initialRawChart.id]).not.toBeDefined();
      expect(rawCharts[expectedChartKey]).toBeDefined();

      expect(rawCharts[expectedDeprecatedByFieldChartKey]).toBeDefined();
      expect(rawCharts[expectedDeprecatedByAnnotationChartKey]).toBeDefined();

      // The targeted version info SHOULD be wiped
      expect(versionInfos[targetedVersionKey]).not.toBeDefined();
      // The unrelated version info should NOT be wiped
      expect(versionInfos[unrelatedVersionKey]).toBeDefined();
      expect(versionInfos[unrelatedVersionKey].data).toBe('keep-me');
    });
  });

  describe('refresh', () => {
    it('calls refresh(false) on all repos and then dispatches a reset load', async() => {
      const mockRepo1 = { refresh: jest.fn().mockResolvedValue(true) };
      const mockRepo2 = { refresh: jest.fn().mockResolvedValue(true) };

      const getters = { repos: [mockRepo1, mockRepo2] };
      const dispatch = jest.fn().mockResolvedValue(true);
      const commit = jest.fn();

      await actions.refresh({
        getters, commit, dispatch
      });

      expect(mockRepo1.refresh).toHaveBeenCalledWith(false);
      expect(mockRepo2.refresh).toHaveBeenCalledWith(false);
      expect(dispatch).toHaveBeenCalledWith('load', { force: true, reset: true });
    });
  });

  describe('filterAndArrangeCharts', () => {
    const mockCharts = [
      {
        chartName:        'chart-a',
        chartNameDisplay: 'Chart Alpha',
        chartDescription: 'Description for Alpha',
        keywords:         ['keyword1', 'keyword2'],
        versions:         [{ annotations: {}, version: '1.0.0' }],
        deprecated:       false,
        hidden:           false,
        repoKey:          'repo1',
        chartType:        'app',
        categories:       [],
        tags:             [],
      },
      {
        chartName:        'chart-b',
        chartNameDisplay: 'Chart Beta',
        chartDescription: 'Description for Beta',
        keywords:         ['keyword2', 'keyword3'],
        versions:         [{ annotations: {}, version: '1.0.0' }],
        deprecated:       false,
        hidden:           false,
        repoKey:          'repo1',
        chartType:        'app',
        categories:       [],
        tags:             [],
      },
      {
        chartName:        'chart-c',
        chartNameDisplay: 'Chart Gamma',
        chartDescription: 'Description for Gamma',
        keywords:         ['keyword3', 'keyword4'],
        versions:         [{ annotations: {}, version: '1.0.0' }],
        deprecated:       false,
        hidden:           false,
        repoKey:          'repo1',
        chartType:        'app',
        categories:       [],
        tags:             [],
      },
    ];

    it('should return all charts when no search query is provided', () => {
      const result = filterAndArrangeCharts(mockCharts, {});

      expect(result).toHaveLength(mockCharts.length);
    });

    it('should filter charts by name', () => {
      const result = filterAndArrangeCharts(mockCharts, { searchQuery: 'Chart Alpha' });

      expect(result).toHaveLength(1);
      expect(result[0].chartNameDisplay).toBe('Chart Alpha');
    });

    it('should filter charts by description', () => {
      const result = filterAndArrangeCharts(mockCharts, { searchQuery: 'Description for Beta' });

      expect(result).toHaveLength(1);
      expect(result[0].chartNameDisplay).toBe('Chart Beta');
    });

    it('should filter charts by keyword', () => {
      const result = filterAndArrangeCharts(mockCharts, { searchQuery: 'keyword1' });

      expect(result).toHaveLength(1);
      expect(result[0].chartNameDisplay).toBe('Chart Alpha');
    });

    it('should handle multiple search tokens', () => {
      const result = filterAndArrangeCharts(mockCharts, { searchQuery: 'Chart, keyword2' });

      expect(result).toHaveLength(2);
    });

    it('should be case-insensitive', () => {
      const result = filterAndArrangeCharts(mockCharts, { searchQuery: 'chart alpha' });

      expect(result).toHaveLength(1);
      expect(result[0].chartNameDisplay).toBe('Chart Alpha');
    });

    it('should return an empty array if no charts match', () => {
      const result = filterAndArrangeCharts(mockCharts, { searchQuery: 'nonexistent' });

      expect(result).toHaveLength(0);
    });
  });

  describe('getters', () => {
    describe('version', () => {
      it('should find a version from a chart, respecting the showDeprecated flag for charts', () => {
        // A regular chart with some versions
        const regularChart = {
          repoType:   'cluster',
          repoName:   'rancher-charts',
          chartName:  'regular-chart',
          deprecated: false,
          versions:   [{ version: '1.2.3' }, { version: '1.2.4' }]
        };
        // A deprecated chart with some versions
        const deprecatedChart = {
          repoType:   'cluster',
          repoName:   'rancher-charts',
          chartName:  'deprecated-chart',
          deprecated: true,
          versions:   [{ version: '2.0.0' }, { version: '2.1.0' }]
        };

        const allCharts = [regularChart, deprecatedChart];
        const localState = state();
        const localGetters = {
          charts: allCharts,
          chart:  (args: any) => getters.chart(localState, { charts: allCharts })(args)
        };

        // Scenario 1: Get a version from a regular chart
        const result1 = getters.version(localState, localGetters)({
          repoType:       'cluster',
          repoName:       'rancher-charts',
          chartName:      'regular-chart',
          versionName:    '1.2.3',
          showDeprecated: false
        });

        expect(result1).toStrictEqual({ version: '1.2.3' });

        // Scenario 2: Get a version from a deprecated chart
        const result2 = getters.version(localState, localGetters)({
          repoType:       'cluster',
          repoName:       'rancher-charts',
          chartName:      'deprecated-chart',
          versionName:    '2.0.0',
          showDeprecated: true
        });

        expect(result2).toStrictEqual({ version: '2.0.0' });

        // Scenario 3: Try to get a version from a deprecated chart without the flag should fail
        const result3 = getters.version(localState, localGetters)({
          repoType:       'cluster',
          repoName:       'rancher-charts',
          chartName:      'deprecated-chart',
          versionName:    '2.0.0',
          showDeprecated: false
        });

        expect(result3).toBeNull();
      });
    });
  });

  describe('isRancherRepo', () => {
    it('should return true if chart.isRancherRepo is true', () => {
      const chart = { isRancherRepo: true } as any;

      expect(isRancherRepo(null, chart)).toBe(true);
    });

    it('should return true if repo.isRancherSource is true', () => {
      const repo = { isRancherSource: true } as any;

      expect(isRancherRepo(repo, null)).toBe(true);
    });

    it('should return false if repo is not a rancher source', () => {
      const repo = { isRancherSource: false } as any;

      expect(isRancherRepo(repo, null)).toBe(false);
    });
  });

  describe('compatibleVersionsFor', () => {
    it('should allow versions if no OS constraint is provided', () => {
      const chart = { versions: [{ version: '1.0.0' }] } as any;
      const versions = compatibleVersionsFor(chart, undefined);

      expect(versions).toHaveLength(1);
    });

    it('should allow windows nodes if permitted-os includes windows', () => {
      const chart = {
        versions: [{
          version:     '1.0.0',
          annotations: { 'catalog.cattle.io/permits-os': 'linux,windows' }
        }]
      } as any;
      const versions = compatibleVersionsFor(chart, 'windows');

      expect(versions).toHaveLength(1);
    });

    it('should block windows nodes if permitted-os does not include windows', () => {
      const chart = {
        versions: [{
          version:     '1.0.0',
          annotations: { 'catalog.cattle.io/permits-os': 'linux' }
        }]
      } as any;
      const versions = compatibleVersionsFor(chart, 'windows');

      expect(versions).toHaveLength(0);
    });

    it('should fallback to LINUX for rancher repos and block windows nodes', () => {
      const chart = { isRancherRepo: true, versions: [{ version: '1.0.0' }] } as any;
      const versions = compatibleVersionsFor(chart, 'windows');

      expect(versions).toHaveLength(0);
    });

    it('should not fallback to LINUX for non-rancher repos and allow windows nodes', () => {
      const chart = { isRancherRepo: false, versions: [{ version: '1.0.0' }] } as any;
      const versions = compatibleVersionsFor(chart, 'windows');

      expect(versions).toHaveLength(1);
    });
  });

  describe('getPermittedOSs', () => {
    it('should return explicitly permitted OSs when the annotation is present on a Rancher repo', () => {
      const annotations = { [CATALOG_ANNOTATIONS.PERMITTED_OS]: 'linux,windows' };
      const result = getPermittedOSs(annotations, true);

      expect(result).toHaveLength(2);
      expect(result).toContain('linux');
      expect(result).toContain('windows');
    });

    it('should return explicitly permitted OSs when the annotation is present on a non-Rancher repo', () => {
      const annotations = { [CATALOG_ANNOTATIONS.PERMITTED_OS]: 'linux' };
      const result = getPermittedOSs(annotations, false);

      expect(result).toHaveLength(1);
      expect(result).toContain('linux');
    });

    it('should fallback to linux if the annotation is missing on a Rancher repo', () => {
      const annotations = {};
      const result = getPermittedOSs(annotations, true);

      expect(result).toHaveLength(1);
      expect(result).toContain('linux');
    });

    it('should return an empty array (no restrictions) if the annotation is missing on a non-Rancher repo', () => {
      const annotations = {};
      const result = getPermittedOSs(annotations, false);

      expect(result).toHaveLength(0);
    });

    it('should handle undefined annotations safely for Rancher repos', () => {
      const result = getPermittedOSs(undefined, true);

      expect(result).toHaveLength(1);
      expect(result).toContain('linux');
    });

    it('should handle undefined annotations safely for non-Rancher repos', () => {
      const result = getPermittedOSs(undefined, false);

      expect(result).toHaveLength(0);
    });
  });
});
